# Professional Dashboard Architecture Guide

## 🎯 Overview

Dieses Dokument beschreibt die neue, professionelle Architektur des Dashboards mit Best Practices für Skalierbarkeit, Wartbarkeit und Performance.

---

## 📐 Design System Foundation

### CSS Variables Structure
```
01-DesignSystem.css
├── Colors (Primary, Semantic, Neutral)
├── Typography (Font families, sizes, weights)
├── Spacing (8px base unit system)
├── Shadows (consistent depth)
├── Border Radius (consistent roundness)
├── Transitions (performance optimized)
└── Z-index scale (layering hierarchy)
```

### Verwendung von CSS Variablen

**❌ Alte Methode (nicht skalierbar):**
```css
.card {
  background: #ffffff;
  padding: 24px;
  border-radius: 16px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
}

.card:hover {
  box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);
}
```

**✅ Neue Methode (skalierbar & wartbar):**
```css
.card {
  background: var(--color-neutral-white);
  padding: var(--spacing-6);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-xs);
  transition: all var(--transition-base);
}

.card:hover {
  box-shadow: var(--shadow-md);
}
```

**Vorteile:**
- 🎨 Zentrale Farbverwaltung
- ⚡ Einfache Theme-Umschaltung (Light/Dark Mode)
- 📱 Responsive Anpassungen nur in CSS Variablen
- 🔄 Konsistente Werte überall

---

## 🧩 Component-Based Architecture

### Struktur

```
src/
├── styles/
│  ├── 01-DesignSystem.css          (Globale Variablen & Reset)
│  ├── 02-ProfessionalDashboard.css (Komponenten)
│  └── components/                  (Komponentenspezifische Styles)
│
├── components/
│  ├── Dashboard/
│  │  ├── ProfessionalDashboard.jsx (Hauptkomponente)
│  │  ├── StatCard.jsx              (Wiederverwendbar)
│  │  ├── ActivityItem.jsx          (Wiederverwendbar)
│  │  └── Dashboard.css             (Komponentenstyles)
│  │
│  ├── Header/
│  ├── Sidebar/
│  └── Layout/
│
└── lib/
   └── supabase.js
```

### Komponenten-Anatomie

#### StatCard Component

**Dateistruktur:**
```
StatCard.jsx
├── Props Definition
├── CSS Classes (BEM Naming)
├── Accessibility (ARIA)
└── Error Handling
```

**Verwendung:**
```jsx
<StatCard
  label="Aktive Kunden"
  value={42}
  unit="Kunden"
  description="Im System registriert"
  icon={Users}
  variant="success"
  isLoading={false}
  onClick={handleClick}
/>
```

**CSS Klassen (BEM Pattern):**
```
.stat-card              (Block)
├── .stat-card__header  (Element)
├── .stat-card__label   (Element)
├── .stat-card__icon    (Element)
├── .stat-card__body    (Element)
├── .stat-card__value   (Element)
├── .stat-card__unit    (Element)
└── .stat-card--success (Modifier)
```

---

## 🎨 Styling Best Practices

### 1. **BEM Naming Convention**
```css
/* ❌ Ungünstig */
.card-header-title { }
.card-header .title { }

/* ✅ Besser */
.card__header { }
.card__title { }
.card__body { }
.card--success { }  /* Modifier */
```

### 2. **Spacing Scale (8px System)**
```
--spacing-1: 4px   (0.25rem)
--spacing-2: 8px   (0.5rem)
--spacing-3: 12px  (0.75rem)
--spacing-4: 16px  (1rem)    ← Standard Padding
--spacing-6: 24px  (1.5rem)  ← Größere Elemente
--spacing-8: 32px  (2rem)    ← Section Spacing
```

Alle Padding/Margin sollten **Multiples von 4px** sein:
```css
/* ❌ Ungünstig */
padding: 13px 19px;

/* ✅ Besser */
padding: var(--spacing-4) var(--spacing-6);  /* 16px 24px */
```

### 3. **Color Usage**
```css
/* ✅ Primärfarben */
background: var(--color-primary-600);      /* Buttons, Highlights */
color: var(--color-neutral-950);           /* Headlines */
color: var(--color-neutral-600);           /* Body Text */

/* ✅ Semantische Farben */
color: var(--color-success);   /* Positive Actions */
color: var(--color-warning);   /* Alerts */
color: var(--color-danger);    /* Destructive */
```

### 4. **Shadows für Tiefe**
```css
box-shadow: var(--shadow-xs);   /* Subtle elevation */
box-shadow: var(--shadow-base); /* Standard cards */
box-shadow: var(--shadow-md);   /* Hover state */
box-shadow: var(--shadow-lg);   /* Modals, Dropdowns */
```

### 5. **Transitions für Smoothness**
```css
transition: all var(--transition-fast);  /* 150ms - Quick feedback */
transition: all var(--transition-base);  /* 200ms - Standard */
transition: all var(--transition-slow);  /* 300ms - Slow animations */
```

---

## 🔄 State Management Patterns

### Data Fetching
```jsx
// ❌ Anti-Pattern: Multiple state updates
const [data1, setData1] = useState(null);
const [data2, setData2] = useState(null);
const [error, setError] = useState(null);

useEffect(() => {
  fetchData1().then(setData1);
  fetchData2().then(setData2);
}, []);

// ✅ Pattern: Single state object + Parallel fetching
const [state, setState] = useState({
  data: {},
  loading: true,
  error: null
});

useEffect(() => {
  Promise.all([
    supabase.from('table1').select(),
    supabase.from('table2').select()
  ])
    .then(([data1, data2]) => {
      setState({ data: { data1, data2 }, loading: false });
    })
    .catch(error => {
      setState({ error, loading: false });
    });
}, []);
```

---

## 📱 Responsive Design Strategy

### Breakpoints
```css
Mobile:  320px - 767px   (Small phones to tablets)
Tablet:  768px - 1023px  (iPad landscape)
Desktop: 1024px+         (Full desktop experience)
```

### Mobile-First Approach
```css
/* ✅ Mobile-first (base styles) */
.grid {
  grid-template-columns: 1fr;
}

/* dann für größere Screens erweitern */
@media (min-width: 768px) {
  .grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (min-width: 1024px) {
  .grid {
    grid-template-columns: repeat(4, 1fr);
  }
}
```

---

## 🚀 Performance Optimizations

### 1. **CSS Effizienzen**
```css
/* ❌ Ineffizient */
.card {
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}
.card:hover {
  box-shadow: 0 10px 15px rgba(0, 0, 0, 0.15);
}

/* ✅ Optimiert */
.card {
  box-shadow: var(--shadow-xs);
  transition: box-shadow var(--transition-base);
}
.card:hover {
  box-shadow: var(--shadow-md);
}
```

### 2. **Rendering Performance**
```jsx
// ❌ Inline Arrow Functions (neuer Function bei jedem Render)
<button onClick={() => handleClick(id)}>

// ✅ Memoized Callbacks
const handleClick = useCallback((id) => {
  // logic
}, []);
```

### 3. **Asset Loading**
```jsx
// ❌ Alle Daten auf einmal laden
const [allData] = useState(() => loadEverything());

// ✅ Lazy Loading
const [data, setData] = useState(null);
useEffect(() => {
  loadInitialData().then(setData);
}, []);
```

---

## 🎯 Accessibility Standards

### ARIA Labels
```jsx
<div 
  className="stat-card"
  role="button"
  tabIndex={0}
  aria-label="Aktive Kunden: 42"
>
  ...
</div>
```

### Color Contrast
```css
/* WCAG AA Standard (min 4.5:1) */
color: var(--color-neutral-950);        /* Dark on light */
color: var(--color-neutral-white);      /* Light on dark */
```

---

## 📋 Häufige Fehler Vermeiden

### ❌ Anti-Patterns

1. **Magic Numbers**
   ```css
   /* Ungünstig */
   padding: 24px;
   /* Besser */
   padding: var(--spacing-6);
   ```

2. **Redundante Styles**
   ```css
   /* Ungünstig */
   .card { border-radius: 16px; }
   .modal { border-radius: 16px; }
   .button { border-radius: 16px; }
   /* Besser - eine Quelle der Wahrheit */
   --radius-lg: 1rem;
   ```

3. **Inline Styles**
   ```jsx
   /* Ungünstig */
   <div style={{ padding: '24px', color: '#0f172a' }} />
   /* Besser */
   <div className="card" />
   ```

4. **Keine Fokus States**
   ```css
   /* Ungünstig */
   .btn:hover { background: blue; }

   /* Besser */
   .btn:hover,
   .btn:focus-visible {
     background: blue;
     outline: 2px solid var(--color-primary-600);
   }
   ```

---

## 🧪 Testing & QA

### CSS Testing
- [ ] Responsiv auf allen Breakpoints
- [ ] Light/Dark Mode funktioniert
- [ ] Kontraste WCAG AA konform
- [ ] Alle Transitionen sind smooth
- [ ] Keine Layout Shifts

### React Component Testing
```jsx
import { render, screen } from '@testing-library/react';

test('StatCard renders with correct value', () => {
  render(
    <StatCard value={42} label="Test" />
  );
  expect(screen.getByText('42')).toBeInTheDocument();
});
```

---

## 📚 Ressourcen

- [CSS Variables - MDN](https://developer.mozilla.org/en-US/docs/Web/CSS/--*)
- [BEM Methodology](http://getbem.com/)
- [WCAG Accessibility](https://www.w3.org/WAI/WCAG21/quickref/)
- [React Best Practices](https://react.dev/learn)

---

**Letzte Aktualisierung:** Dezember 2024
**Version:** 1.0
